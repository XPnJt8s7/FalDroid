package Util.FamilyStatistic;

import CommunityStructure.CommunityDetection.AllObjectCommunityDetection;

public class CommunityDetection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long startTime=System.currentTimeMillis();
		GenerateCommunity();
		
		 long endTime=System.currentTimeMillis();
		 long dureTime=endTime-startTime;
		 System.out.println(dureTime+"ms");
	}
	public static void GenerateCommunity(){
		AllObjectCommunityDetection communityDetection=new AllObjectCommunityDetection();
	}
	
}
