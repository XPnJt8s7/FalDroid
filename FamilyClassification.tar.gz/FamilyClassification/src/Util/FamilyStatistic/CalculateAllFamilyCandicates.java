package Util.FamilyStatistic;

import java.io.File;

import CandicateFamily.FamilyCandicateStatistic;
import ConstantVar.ConstantValue;

/*
 *     实验第三步，计算候选家族
 * 	计算每一个家族成员实例的候选家族，并写入FamilyInfo文件夹中的CandicateFamilies文件夹中
 * 	命名方式为top=k.csv, 其中k为 候选家族的数量
 */
public class CalculateAllFamilyCandicates {
	public static int allPredictNum=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			long startTime=System.currentTimeMillis();
			ConstantValue.getVar();
			for(int i=1;i<31;i++){
				calculateCandicateFamily(i);
			}
			 long endTime=System.currentTimeMillis();
			 long dureTime=endTime-startTime;
			 System.out.println(dureTime+"ms");
	}
	public static void calculateCandicateFamily(int k){
		ConstantValue.TopFalNumber=k;
		allPredictNum=0;
		System.out.println("*****************"+"Top K="+ConstantValue.TopFalNumber+"**************************");
		ConstantValue.getVar();
		String srcDataFileString=ConstantValue.FAMILIESDIRPATH_STRING;
		File srcDir=new File(srcDataFileString);
		File familyDir[]=srcDir.listFiles();
		for(int i=0;i<familyDir.length;i++){
			String familyDirPathString=familyDir[i].getAbsolutePath()+"/";
			FamilyCandicateStatistic falStatistic=new FamilyCandicateStatistic(familyDirPathString);
			System.out.println(falStatistic.getStatisticString());
			allPredictNum +=falStatistic.getPredictNum();
			//System.out.println("Finish "+familyDir[i].getName());
		}
		ConstantValue.getVar();
		//System.out.println("Total Predict Rate:	"+allPredictNum+"/"+ConstantValue.TotalInstanceNumber);
	}

}
