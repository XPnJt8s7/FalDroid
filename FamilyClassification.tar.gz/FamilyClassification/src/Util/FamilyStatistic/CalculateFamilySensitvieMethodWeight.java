package Util.FamilyStatistic;

import TFIDF.AllFamilyInfo;
import ConstantVar.ConstantValue;
/*    实验第二步，　计算敏感函数权重
 *    计算每一个家族中每一个敏感函数的权重，并写入在家族文件夹FamilyInfo中的MethodWeight.txt中
 * 
 */
public class CalculateFamilySensitvieMethodWeight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long startTime=System.currentTimeMillis();
		ConstantValue.getVar();
		String dirPathString = ConstantValue.FAMILIESDIRPATH_STRING;
		AllFamilyInfo allFamilyInfo=new AllFamilyInfo(dirPathString);
		allFamilyInfo.writeFamiliesInfo();
		 long endTime=System.currentTimeMillis();
		 long dureTime=endTime-startTime;
		 System.out.println(dureTime+"ms");
	}
}
