package Util.FamilyStatistic;

import java.io.File;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import ConstantVar.ConstantValue;
import GraphSimilarity.HierarchicalClustering.FamilyClusterResult;
import Util.BasicStatisticExperiment.GenerateTrainFile;

/*
 *       给每一个家族分析其聚类结果，
 *       函数OneFamilyClusterResult生成一个家族的子图聚类结果
 */
public class GetFamilyClusterResult {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Double> supportSetInt=new HashSet<>();
		supportSetInt.add(0.1D); 
		supportSetInt.add(0.2D);
		supportSetInt.add(0.3D);		
		supportSetInt.add(0.4D);		
		supportSetInt.add(0.5D);		
		supportSetInt.add(0.6D);		
		supportSetInt.add(0.7D);  
		supportSetInt.add(0.8D);	
		supportSetInt.add(0.9D);	
		Iterator<Double> iterator=supportSetInt.iterator();
		while(iterator.hasNext()){
			double sur=iterator.next();
			System.out.println(sur);
			oneSupportType(sur);
		}
	}
	public static void oneSupportType(double support){
		ConstantValue.getVar().minSupport=support;
		System.out.println("Start supprot :"+ConstantValue.getVar().minSupport+"********************************************");
		File dataFile=new File(ConstantValue.getVar().FAMILIESDIRPATH_STRING);
	    File family[]=dataFile.listFiles();
	    for(int i=0;i<family.length;i++){
	//    	if(family[i].getName().contains("dowgin")){
	    	System.out.println("**************************Start Family "+i+":"+family[i].getName()+" ************************");
	    	String familyDir=family[i].getAbsolutePath()+"/";
	    	String type="Im";
	    	OneFamilyClusterResult(familyDir, type);
	    	ConstantValue.getVar().iniValue();
	    	System.out.println("**************************Finish Family "+i+":"+family[i].getName()+" ************************");
//	   	}
	  }
	    System.out.println("Finish supprot :"+ConstantValue.getVar().minSupport+"********************************************");
	}

	public static void OneFamilyClusterResult(String familyDirPath, String type){
		 FamilyClusterResult clusterResult=new FamilyClusterResult(familyDirPath, type);
	}
}
