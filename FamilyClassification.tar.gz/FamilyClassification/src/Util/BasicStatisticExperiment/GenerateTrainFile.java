package Util.BasicStatisticExperiment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


import ConstantVar.ConstantValue;
import Exp.ClassifyByVector.APKSiggraphSet;
import Exp.ClassifyByVector.FregraphVector;
import Exp.ClassifyByVector.SiggraphVector;

public class GenerateTrainFile {
	public static String arff="";
	public static String clusterType="";
	public static String testDataString="/home/fan/lab/Family/extend/test/";
	public static String trainDataString="/home/fan/lab/Family/extend/train/";
	public static String resultDataString="/home/fan/lab/Family/extend/result-score/";
//	public static String featureSpaceFilePath="/home/fan/data/Family/small-sample-exp/exp4/result/feature-0.5.txt";
	
	public static ArrayList<String> TimeList=new ArrayList<>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> supportSet=new HashSet<>();
//		supportSet.add("0.1");     
//		supportSet.add("0.2");
//		supportSet.add("0.3");		
//		supportSet.add("0.4");		
		supportSet.add("0.5");		
		supportSet.add("0.6");		
		supportSet.add("0.7");
	    supportSet.add("0.8");	
//	    supportSet.add("0.9");
		Iterator<String> iterator=supportSet.iterator();
		while(iterator.hasNext()){
			String sur=iterator.next();
			System.out.println(sur);
			oneSupportType(sur);
		}
//		oneSupportType("0.6");
	}
	public static void oneSupportType(String support){
		try {
			TimeList=new ArrayList<>();
			clusterType="Im--"+support;

			 SiggraphVector vector=new SiggraphVector(clusterType); 
			 FregraphVector fregraphVector=new FregraphVector(vector);
			 
//			 for(int i=0;i<fregraphVector.fregraphList.size();i++){
//				 System.out.println(fregraphVector.fregraphList.get(i).getFeatureLabel()+"---"+
//						 fregraphVector.fregraphList.get(i).weight);
//			 }
			 
			 fregraphVector.reorderFregraphList();
			 System.out.println("********************************");
			 for(int i=0;i<fregraphVector.fregraphList.size();i++){
				 System.out.println(fregraphVector.fregraphList.get(i).getFeatureLabel()+"---"+
						 fregraphVector.fregraphList.get(i).weight);
			 }
			 
//			 String featureSpaceFile="//home/fan/lab/Family/small-size/exp5/result/featureSpace/featureSpace-"+support+".model";
//			 writeFeatureSpace(featureSpaceFile, fregraphVector);
//			 
//			 FregraphVector fregraphVector=readFeatureSpace(featureSpaceFile);
	         
//			 
			writeTrainFile(fregraphVector);
			writeTestFile(fregraphVector);
			writeTimeFile();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	
		
	}
	public static void writeFeatureSpace(String writeFilePath, FregraphVector fregraphVector){
		try {
			 ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(writeFilePath));
			 oos.writeObject(fregraphVector);
			 oos.flush();
			 oos.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public static FregraphVector readFeatureSpace(String readFilePath){
		
		try {
			
			ObjectInputStream in=new ObjectInputStream(new FileInputStream(readFilePath));
			FregraphVector vector= (FregraphVector) in.readObject();
			in.close();
			System.out.println(vector.fregraphList.size());
			return vector;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	public static void writeTrainFile(FregraphVector vector){
		getHeader(vector);
		File dataFile=new File(trainDataString);
		File fals[]=dataFile.listFiles();
		for(int i=0;i<fals.length;i++){
			String falFileString=fals[i].getAbsolutePath()+"/";
				arff += getOneFalVector(falFileString, vector);
		}
		String writeFile=resultDataString+clusterType+"-train.arff";
		writeFile(writeFile);
	}
	public static void writeTestFile(FregraphVector vector){
		getHeader(vector);
		File dataFile=new File(testDataString);
		File fals[]=dataFile.listFiles();
		for(int i=0;i<fals.length;i++){
			String falFileString=fals[i].getAbsolutePath()+"/";
			System.out.println("Family: "+falFileString);
				arff += getOneFalVector(falFileString, vector);
		}
		String writeFile=resultDataString+clusterType+"-test.arff";
		writeFile(writeFile);
	}
	public static void writeTimeFile(){
		String writeFile=resultDataString+clusterType+"-Time.txt";
		try {
			File file=new File(writeFile);
			FileWriter fWriter=new FileWriter(file);
			BufferedWriter bWriter=new BufferedWriter(fWriter);
			for(int i=0;i<TimeList.size();i++){
				String time=TimeList.get(i);
				bWriter.write(time+"\n");
			}
			bWriter.close();
			fWriter.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public static void getHeader(FregraphVector vector){
		arff ="@relation FamilyClassificationTrainingDataset\n";
		arff +=vector.getFeatureNameList();
		arff +="@attribute label {";
		String labelList="";
		File dataFile=new File(ConstantValue.getVar().FAMILIESDIRPATH_STRING);
		File falDir[]=dataFile.listFiles();
		for(int i=0;i<falDir.length;i++){
			String name=falDir[i].getName();
			labelList +=name+",";
		}
		labelList = labelList.substring(0,labelList.length()-1);
		arff +=labelList+"}\n\n";
		arff +="@data\n";
	}
	public static String getOneFalVector(String falDirPath, FregraphVector vector){
		String falString="";
		File falFile=new File(falDirPath);
		File apks[]=falFile.listFiles();
		for(int i=0;i<apks.length;i++){
			if(apks[i].getName().endsWith(".apk")){
				String apkFilePath=apks[i].getAbsolutePath();
				falString +=getOneAPKVector(apkFilePath, vector)+"\n";
				System.out.println(falDirPath+":"+apks[i].getName()+"   #"+i);
			}
		}
		return falString;
	}
	public static String getOneAPKVector(String apkFilePath, FregraphVector vector){
		APKSiggraphSet siggraphSet=new APKSiggraphSet(apkFilePath, clusterType);
		
		/*
		 *    对于 未知样本来说，一开始并不知道每一个函数的权重分值，需要初始一个分值列表来
		 *    给每一个生成的子图进行命名，对后面并不造成影响，在具体检测的时候，会根据目标家族
		 *    的分值列表进行子图分值的重新计算
		 *    
		 */
		long startTime=System.currentTimeMillis();
		
		siggraphSet.storeAllSubgraphs();
		siggraphSet.storeAllSignificantSubgraphs();
		
		
		siggraphSet.generateVector(vector);
		
//		String vectorString=siggraphSet.getFeatureIntVector();
		String vectorString=siggraphSet.getFeatureDoubleVector();
		long endTime=System.currentTimeMillis();
		long useTime=endTime-startTime;
		String time=String.valueOf(useTime);
		TimeList.add(time);
		return vectorString;
	}
	public static void writeFile(String writeFilePath){
		try {
			File file=new File(writeFilePath);
			FileWriter fWriter=new FileWriter(file);
			BufferedWriter bWriter=new BufferedWriter(fWriter);
			bWriter.write(arff);
			bWriter.close();
			fWriter.close();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
}
