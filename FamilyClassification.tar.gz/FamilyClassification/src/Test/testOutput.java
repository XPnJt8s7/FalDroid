package Test;

public class testOutput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         String syString=args[0];
         System.out.println(syString);
	}

}
