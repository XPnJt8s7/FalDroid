package Test;

import APKData.SmaliGraph.GexfToGraph;
import APKData.SmaliGraph.MethodEdge;
import APKData.SmaliGraph.MethodNode;

public class testGexfToGraph {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				String gexfFilePath="/home/fan/lab/FamilyClassification/test/0.110--3.399--13.gexf";
				GexfToGraph graph=new GexfToGraph(gexfFilePath);
				
	}

}
