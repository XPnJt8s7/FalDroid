package GED.GEDofGraphs;

public class Edge {
	private int Source;
	private int Target;
	private int weight;
	public int getSource(){
		return this.Source;
	}
	
	public void setSource(int Source){
		this.Source=Source;
	}
	
	public int getTarget(){
		return this.Target;
	}
	
	public void setTarget(int Target){
		this.Target=Target;
	}
	
	public int getweight(){
		return this.weight;
	}
	
	public void setweight(int weight){
		this.weight=weight;
	}

}
