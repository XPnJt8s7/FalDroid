package Journal.APKSim;

import java.util.ArrayList;

public class ClusterAPK {
	public ArrayList<APKObj> apkList=new ArrayList<>();
	
	public ClusterAPK(){
		
	}
	public ClusterAPK(String inputFilePath){
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
}
