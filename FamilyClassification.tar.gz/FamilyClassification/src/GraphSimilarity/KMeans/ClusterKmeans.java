package GraphSimilarity.KMeans;
/*
 * 				由于Kmeans算法需要一开始指定k值，本算法借助kmeans思想
 * 				依次将子图集合中的每一个元素与已知簇进行相似性计算，如果，大于阈值，那么就将该子图加入到
 *              该簇中；如果，新来的子图元素并不与任意一个簇相似，那么新建一个簇，将该子图作为该新簇的第一个
 *              元素存储
 */

import java.util.ArrayList;

import CandicateFamily.FamilyWeightScore;
import ConstantVar.ConstantValue;
import GraphSimilarity.CommunitySubGraph;
import GraphSimilarity.HierarchicalClustering.Cluster;

public class ClusterKmeans {
		
	public ArrayList<Cluster> clusterList=new ArrayList<>();
	public ArrayList<CommunitySubGraph> graphList=new ArrayList<>();
	public int familyNum;
	public String familyDirString="";
	public FamilyWeightScore weightScore;
	/*
	 *     输入参数为子图列表，以及相应家族的样本个数,以及相应家族的文件位置
	 */
	public ClusterKmeans(ArrayList<CommunitySubGraph> graphList, int familyNum,String familyDirString){
		this.graphList=graphList;
		this.familyDirString=familyDirString;
		this.familyNum=familyNum;
		weightScore=new FamilyWeightScore(this.familyDirString+"FamilyInfo/MethodWeight.txt");
		iniClusterList();
		surpport(familyNum);
	}
	
	public void iniClusterList(){
		for(int i=0;i<graphList.size();i++){
			CommunitySubGraph subGraph=new CommunitySubGraph();
			subGraph=graphList.get(i);
			/*
			 *     当前簇个数为0,对于第一个元素新建一个簇然后将其放入
			 */
			if(clusterList.size()==0){
				Cluster cluster=new Cluster();
				cluster.addOneSubgraph(subGraph);
				cluster.addOneIndex(i);
				clusterList.add(cluster);
			}
			else{
				/*
				 *    否则，计算当前子图与已知簇的相似度，如果大于阈值，则将其加入到相应的簇中
				 *    find为真表示找到相应簇
				 */
				boolean find=false;
				int index=-1;
				for(int j=0;j<clusterList.size();j++){
					double sim=clusterList.get(j).getAverageSimForOneGraph(subGraph, weightScore);
					if(sim>=ConstantValue.getVar().minScoreSim){
							find=true;
							index=j;
							break;
					}
				}
				if(find==true){
					clusterList.get(index).addOneSubgraph(subGraph);
					clusterList.get(index).addOneIndex(i);
				}
				else{
					Cluster cluster=new Cluster();
					cluster.addOneSubgraph(subGraph);
					cluster.addOneIndex(i);
					clusterList.add(cluster);
				}
			}
		}
	}
    public String getClusterResult(){
 	   String result="";
 	   for(int i=0;i<clusterList.size();i++){
 		   result += "Cluster "+i+" :  #"+clusterList.get(i).getSignificantSubgraph().getFileName()+"#"+clusterList.get(i).getApkSubgraphNameMap().size()+"\n";
 		   result +=clusterList.get(i).getClusterInfo();
 	   }
 	   return result;
    }
    public void surpport(int familyNum){
 	   int min=(int)(ConstantValue.getVar().minSupport*familyNum);
 	//   int min=(int) ConstantValue.getVar().minUnknownNum;   //the min support value in the unknown cluster.
 	   ArrayList<Cluster> newClusterList=new ArrayList<>();
 	   for(int i=0;i<clusterList.size();i++){
 		   clusterList.get(i).iniApkNameSet();
 		   if(clusterList.get(i).getApkSubgraphNameMap().size()>=min){
 			   newClusterList.add(clusterList.get(i));
 		   }
 	   }
 	   this.clusterList=newClusterList;
    }
	public ArrayList<Cluster> getClusterList() {
		return clusterList;
	}

	public void setClusterList(ArrayList<Cluster> clusterList) {
		this.clusterList = clusterList;
	}

	public ArrayList<CommunitySubGraph> getGraphList() {
		return graphList;
	}

	public void setGraphList(ArrayList<CommunitySubGraph> graphList) {
		this.graphList = graphList;
	}

	public int getFamilyNum() {
		return familyNum;
	}

	public void setFamilyNum(int familyNum) {
		this.familyNum = familyNum;
	}

	public String getFamilyDirString() {
		return familyDirString;
	}

	public void setFamilyDirString(String familyDirString) {
		this.familyDirString = familyDirString;
	}

	public FamilyWeightScore getWeightScore() {
		return weightScore;
	}

	public void setWeightScore(FamilyWeightScore weightScore) {
		this.weightScore = weightScore;
	}
		
}
