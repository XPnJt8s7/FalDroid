package GraphSimilarity;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import CandicateFamily.FamilyWeightScore;
import ConstantVar.ConstantValue;
import Util.Tool.QuickSort;
import sun.tools.jar.resources.jar;

/*
 *      输入为一个家族的根目录，以及相关的社团划分算法
 *      通过一些选择条件挑选 分值高于既定阈值的子图集合： reduceGraphList，
 *      然后计算graphList所有元素两两之间的相似性，并构建相似性矩阵
 *      由于 子图元素个数庞大，相似性计算开销较大，因此当
 *      1. 两个子图的分值比例小于 最小相似性阈值的时候，相似性为0
 *      
 */

public class FamilySubGraphSet {
          private ArrayList<SubGraphSet> subGraphSetList=new ArrayList<>();
          private String familyDirString="";
          private String comType="";
          private double[][] simMatrix;
          private int subgraphSize=0;
          private ArrayList<CommunitySubGraph> graphList=new ArrayList<>();
          private double senScore[];
          
          public FamilySubGraphSet(String  familyDirString, String comType) {
			// TODO Auto-generated constructor stub
        	  this.familyDirString=familyDirString;
        	  this.comType=comType;
        	  long starttime=System.currentTimeMillis();
        	  iniSubGraphSetList();
        	  iniGraphList();
        	  long inigraphListTime=System.currentTimeMillis();
        	  System.out.println("Finish getting graphList: "+(inigraphListTime-starttime)+"ms");
        	  reduceGraphList();
        	  long reduceGraphListTime=System.currentTimeMillis();
        	  System.out.println("Finish reducing graphList: "+(reduceGraphListTime-inigraphListTime)+"ms");
//         	 iniSimMatrix();
//         	 long iniSimMatrixTime=System.currentTimeMillis();
//         	 System.out.println("Finish constructing similarity matrix: "+(iniSimMatrixTime-reduceGraphListTime)+"ms");
		}
         /*
          *    初始化SubgraphSetList列表
          *    每一个成员维护一个subgraphSet， 因而一个家族包含一个subgraphSet的List列表
          */
         public void iniSubGraphSetList(){
        	 String apktoolDir=this.familyDirString+"apktool/";
        	 File apktool=new File(apktoolDir);
        	 File apks[]=apktool.listFiles();
        	 for(int i=0;i<apks.length;i++){
        		 /*
        		  * 	将每一个样本中的满足条件的子图存储在subgraphSet中
        		  * 	注意： 这里的条件指的是0.058--0.173--76.gexf
        		  * 	前面的参数大于minAvgGraphScore，后面的参数大于minTotalGraphScore
        		  * 	默认情况下两个参数阈值均为0.0D,即将不包含敏感函数节点的子图删除
        		  */
        		 String comDir=apks[i].getAbsolutePath()+"/SICG/Community/Community_"+comType+"/";
        		 SubGraphSet subGraphSet=new SubGraphSet(comDir);
        		 /*
        		  *     设置 该子图集合的所在apk名字
        		  */
        		 String apkName=apks[i].getName();
        		 subGraphSet.setApkName(apkName);
        		 subGraphSetList.add(subGraphSet);
        		 subgraphSize += subGraphSet.getSize();
        		 System.out.println("APK :"+i+" --- "+subgraphSize);
        	 }
         }
         /*
          *  初始化graphList
          */
         public void iniGraphList(){
        	 for(int i=0;i<subGraphSetList.size();i++){
        		 for(int j=0;j<subGraphSetList.get(i).getGraphList().size();j++){
        			 this.graphList.add(subGraphSetList.get(i).getGraphList().get(j));
        		 }
        	 }
        	 subGraphSetList=new ArrayList<>();          //释放subGraphSetList内的空间
         }
         /*
          *     删除不满足条件的子图
          */
         public void reduceGraphList(){
        	 long startReduceTime=System.currentTimeMillis();
        	 
        	 double [] score=new double[graphList.size()];
        	 for(int i=0;i<graphList.size();i++){
        		 score[i]=graphList.get(i).getSensitiveScore();
        	 }
        	 QuickSort sort=new QuickSort();
        	 sort.quick(score);
        	 System.out.println("Source: "+graphList.size());
        	 double upQuartValue=0.0D;
        	 int index=0;
        	index=(int) (this.subgraphSize * (ConstantValue.getVar().minTotalGraphScoreRatio));
         	upQuartValue =score[index];
         	ConstantValue.getVar().minTotalGraphScore=upQuartValue;
        	
        	 // 删除敏感系数小于阈值的子图
        	 
        	 ArrayList<CommunitySubGraph> newGraphList=new ArrayList<>();
        	 for(int i=0;i<graphList.size();i++){
        		 if(graphList.get(i).getSensitiveScore()>=ConstantValue.minTotalGraphScore){
        			 newGraphList.add(graphList.get(i));
        		 }
        	 }
        	// ConstantValue.getVar().minTotalGraphScore=0.0D;
        	 this.graphList=new ArrayList<>();
        	 graphList=newGraphList;
        	 this.subgraphSize=graphList.size();
        	 newGraphList=new ArrayList<>();
        	 System.out.println("Reduced :"+ graphList.size());
        	 System.out.println("UpQuartValue: "+ upQuartValue);
        	 long endReduceTime=System.currentTimeMillis();
        	 long usingReduceTime=endReduceTime-startReduceTime;
//        	 System.out.println("Reduce Using Time: "+ usingReduceTime+"ms");
         }
         /*
          *     构建相似性矩阵
          * 
          */
         public void iniSimMatrix(){
        	 System.out.println("Subgraph Size:"+this.subgraphSize);
        	 simMatrix=new double[this.subgraphSize][this.subgraphSize];
        	 String familyWeightFilePath=this.familyDirString+"FamilyInfo/MethodWeight.txt";
        	 FamilyWeightScore weightScore=new FamilyWeightScore(familyWeightFilePath);
        	 double sim=0.0D;
        	 for(int i=0;i<this.subgraphSize;i++){
        		 for(int j=i;j<this.subgraphSize;j++){
        			 if(i==j){
        				 sim=-1.0D;
        			 }
        			 else{
        				 CommunitySubGraph srcSubGraph=new CommunitySubGraph();
 						CommunitySubGraph dstSubGraph=new CommunitySubGraph();
 						srcSubGraph=graphList.get(i);
 						dstSubGraph=graphList.get(j);
 						if(calculateCondition(srcSubGraph, dstSubGraph)){
 							try {
 								SubGraphSimilarity similarity=new SubGraphSimilarity(srcSubGraph.getGraph(),
 		 								dstSubGraph.getGraph(), weightScore);
 		 						simMatrix[i][j]=similarity.getSimScore();
 		 						DecimalFormat    df   = new DecimalFormat("######0.000");   
 		 						String value=df.format(simMatrix[i][j]);
 		 						simMatrix[i][j]=Double.valueOf(value);
 		 						simMatrix[j][i]=Double.valueOf(value);
							} catch (Exception e) {
								// TODO: handle exception
								//   由于某个子图会出现不联通情况，因此计算距离的时候会导致异常出现，
								//   暂时处理方式为 将其相似性设置为0
								System.out.println(srcSubGraph.getFilePath()+"----"+dstSubGraph.getFilePath());
								simMatrix[i][j]=0.0D;
							}
	 						
 						}
 						else {
							simMatrix[i][j]=0.0D;
						}
        			 }
        		 }
        	 }
         }
         public void showSimMatrix(){
        	 for(int i=0;i<this.subgraphSize;i++){
        		 System.out.println();
        		 for(int j=0;j<subgraphSize;j++){
        			 System.out.print(simMatrix[i][j]+", ");
        		 }
        	 }
         }
//         public void processMatrix(){
//        	 ArrayList<CommunitySubGraph> noSimGraphList=new ArrayList<>();
//        	 for(int i=0;i<subgraphSize;i++){
//        		 boolean allLess=true;
//        		 for(int j=0;j<subgraphSize;j++){
//        			 if(simMatrix[i][j] > ConstantValue.getVar().minScoreSim){
//        				 allLess=false;
//        			 }
//        		 }
//        		 if(allLess==true){
//        			 // 删除第 i行 和第i列
//        		 }
//        	 }
//         }
         public boolean calculateCondition(CommunitySubGraph srcSubGraph, CommunitySubGraph dstSubGraph){
        	 double srcSenScore=srcSubGraph.getSensitiveScore();
        	 double dstSenScore=dstSubGraph.getSensitiveScore();
        	 double ratio=getMinDouble(srcSenScore, dstSenScore)/getMaxDouble(srcSenScore, dstSenScore);
        	 if(ratio>ConstantValue.getVar().minScoreSim){
        		 return true;
        	 }
        	 return false;
         }
         public double getMaxDouble(double a, double b){
        	 if(a>=b){
        		 return a;
        	 }
        	 else {
				return b;
			}
         }
         public double getMinDouble(double a, double b){
        	 if(a<b){
        		 return a;
        	 }
        	 else {
				return b;
			}
         }
		public ArrayList<SubGraphSet> getSubGraphSetList() {
			return subGraphSetList;
		}
		public void setSubGraphSetList(ArrayList<SubGraphSet> subGraphSetList) {
			this.subGraphSetList = subGraphSetList;
		}
		public String getFamilyDirString() {
			return familyDirString;
		}
		public void setFamilyDirString(String familyDirString) {
			this.familyDirString = familyDirString;
		}
		public String getComType() {
			return comType;
		}
		public void setComType(String comType) {
			this.comType = comType;
		}
		public double[][] getSimMatrix() {
			return simMatrix;
		}
		public void setSimMatrix(double[][] simMatrix) {
			this.simMatrix = simMatrix;
		}
		public int getSubgraphSize() {
			return subgraphSize;
		}
		public void setSubgraphSize(int subgraphSize) {
			this.subgraphSize = subgraphSize;
		}
		public ArrayList<CommunitySubGraph> getGraphList() {
			return graphList;
		}
		public void setGraphList(ArrayList<CommunitySubGraph> graphList) {
			this.graphList = graphList;
		}
         
}
