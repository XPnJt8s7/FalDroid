package Exp.ClassifyByVector;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;

import javax.sound.midi.VoiceStatus;

import ConstantVar.ConstantValue;

public class SiggraphVector implements Serializable {
	private String clusterType="";
	private ArrayList<Siggraph> allSiggraphList=new ArrayList<>(); 
	private ArrayList<SiggraphFeature> featureList=new ArrayList<>();
	public SiggraphVector(){}
	public SiggraphVector(String clsuterType){
		this.clusterType=clsuterType;
		iniSiggraphList();
		constructFeature();
		assignWeight();
	}
	public SiggraphVector(String featureSpaceFilePath, String clusterType){
		try {
			File file=new File(featureSpaceFilePath);
			FileReader fReader=new FileReader(file);
			BufferedReader bReader=new BufferedReader(fReader);
			String line="";
			while((line=bReader.readLine())!=null){
				if(line.contains("@attribute")&&line.contains("Cluster")){
					String tmps[]=line.split(" ");
					String featureFilePath=tmps[1];
					SiggraphFeature siggraphFeature=new SiggraphFeature();
					siggraphFeature.addSigraph(new Siggraph(featureFilePath));
					siggraphFeature.setWeight(1.0D);
			        featureList.add(siggraphFeature);
				}
				else if(line.contains("#")){
					String tmps[]=line.split(" # ");
					String featureFilePath=tmps[0];
					SiggraphFeature siggraphFeature=new SiggraphFeature();
					siggraphFeature.addSigraph(new Siggraph(featureFilePath));
					siggraphFeature.setWeight(Double.valueOf(tmps[1]));
					featureList.add(siggraphFeature);
				}
			}
			
			bReader.close();
			fReader.close();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public double maxWeight(){
		double max=-1000.0D;
		for(int i=0;i<featureList.size();i++){
			double tmp=featureList.get(i).getWeight();
			if(tmp>max){
				max=tmp;
			}
		}
		return max;
	}
	public double minWeight(){
		double min=1000.0D;
		for(int i=0;i<featureList.size();i++){
			double tmp=featureList.get(i).getWeight();
			if(tmp<min){
				min=tmp;
			}
		}
		return min;
	}
	public void assignWeight(){
		for(int i=0;i<featureList.size();i++){
			double weight=featureList.get(i).getEntropy();
			featureList.get(i).setWeight(weight);
		}
		double maxW=maxWeight();
		double minW=minWeight();
		for(int i=0;i<featureList.size();i++){
			double tmp=(featureList.get(i).getWeight()-minW)/(maxW-minW);
			double score=featureList.get(i).getScore();
			featureList.get(i).setWeight(tmp*score);
		}
	}
	public void writeFeatrueSpace(String writeFilePath ){
		try {
			File file=new File(writeFilePath);
			FileWriter fWriter=new FileWriter(file);
			BufferedWriter bWriter=new BufferedWriter(fWriter);
			for(int i=0;i<featureList.size();i++){
				String line=featureList.get(i).getFeatureLabel()+" # "+featureList.get(i).getWeight()+"\n";
				bWriter.write(line);
			}
			
			bWriter.close();
			fWriter.close();
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	/*
	 *     首先对每一个家族中的显著性子图以一个对象Siggraph进行存储
	 */
	public void iniSiggraphList(){
		try {
			long startTime=System.currentTimeMillis();
			File dataFile=new File(ConstantValue.getVar().FAMILIESDIRPATH_STRING);
			File family[]=dataFile.listFiles();
			for(int i=0;i<family.length;i++){
				String clusterFilePath=family[i].getAbsolutePath()+"/FamilyInfo/"+clusterType+"/";
				File logFile=new File(clusterFilePath+"log.txt");
				FileReader fReader=new FileReader(logFile);
				BufferedReader bReader=new BufferedReader(fReader);
				String lineString="";
				int size=0;
				while((lineString=bReader.readLine())!=null){
					if(lineString.contains("Family Size:")){
						String args[]=lineString.split(": ");
						size=Integer.valueOf(args[1]);
					}
					if(lineString.contains("#")){
						String args[]=lineString.split("#");
						String fileName=args[1];
						String sup=args[2];
						String filePath=clusterFilePath+"Cluster/"+fileName;
						Siggraph siggraph=new Siggraph(filePath);
						int support=Integer.valueOf(sup);
						siggraph.setSupport(support);     // 设置子图的支持度
						siggraph.setFalSize(size);    //设置子图所在家族的样本个数
						this.allSiggraphList.add(siggraph);
					}
				}
				bReader.close();
				fReader.close();
			}
			long endTime=System.currentTimeMillis();
			long useTime=endTime-startTime;
			System.out.println(allSiggraphList.size());
			System.out.println("抽取所有显著性子图耗时："+useTime+"ms");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	public void DrebinMergeFeature(){
		try {
			long startTime=System.currentTimeMillis();
			for(int i=0;i<allSiggraphList.size();i++){
				Siggraph siggraph=allSiggraphList.get(i);
				SiggraphFeature feature=new SiggraphFeature(siggraph);
				feature.setWeight(1.0D);
				featureList.add(feature);
				
			}
			long endtime=System.currentTimeMillis();
			long usetime=endtime-startTime;
			System.out.println("构建显著性子图特征空间耗时："+usetime+"ms");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	/*
	 *     构建特征向量，合并相同显著性子图
	 */
	public void constructFeature(){
		try {
		long startTime=System.currentTimeMillis();
		for(int i=0;i<allSiggraphList.size();i++){
			Siggraph siggraph=allSiggraphList.get(i);
			if(featureList.size()==0){
				SiggraphFeature feature=new SiggraphFeature(siggraph);
				featureList.add(feature);
			}
			else{
				boolean canAddFeature=false;
				for(int j=0;j<featureList.size();j++){
					if(featureList.get(j).canAddSiggraph(siggraph)){
						canAddFeature=true;
						featureList.get(j).addSigraph(siggraph);
						break;
					}
				}
				if(canAddFeature==false){
					SiggraphFeature feature=new SiggraphFeature(siggraph);
					featureList.add(feature);
				}
			}
			System.out.println("Add feature: "+i+"/ "+allSiggraphList.size());
		}
		long endtime=System.currentTimeMillis();
		long usetime=endtime-startTime;
		System.out.println("构建显著性子图特征空间耗时："+usetime+"ms");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void showFeature(){
		for(int i=0;i<featureList.size();i++){
			System.out.println(featureList.get(i).FeatureString());
		}
	}
	public ArrayList<SiggraphFeature> getFeatureList() {
		return featureList;
	}
	public void setFeatureList(ArrayList<SiggraphFeature> featureList) {
		this.featureList = featureList;
	}
	/*
	 *    构建所有特征子图的名称列表
	 */
   public String getFeatureNameList(){
	   String featureString="";
	   for(int i=0;i<featureList.size();i++){
		   featureString += "@attribute "+featureList.get(i).getFeatureLabel()+" numeric\n";
	   }
	   return featureString;
   }
   
   
}
