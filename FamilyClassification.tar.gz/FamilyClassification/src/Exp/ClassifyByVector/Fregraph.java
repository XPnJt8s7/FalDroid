package Exp.ClassifyByVector;

import java.io.Serializable;
import java.util.ArrayList;

public class Fregraph implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5216891263759377623L;
	public ArrayList<String> sameGraphList=new ArrayList<>();
	public double weight=0.0D;
	
	public Fregraph(){
		
	}
	public Fregraph(SiggraphFeature feature){
		for(int i=0;i<feature.siggraphList.size();i++){
			String graphFilePath=feature.siggraphList.get(i).getFilePath();
			sameGraphList.add(graphFilePath);
		}
		this.weight=feature.getWeight();
	}
	//  将该特征中的第一个子图当做特征的标签
	public String getFeatureLabel(){
		String reString="";
		if(sameGraphList.size()>0){
			reString=sameGraphList.get(0);
		}
		return reString;
	}
	public boolean inFeature(String line){
		if(sameGraphList.contains(line)){
			return true;
		}
		return false;
	}
}
