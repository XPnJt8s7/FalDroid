package Exp.ClassifyByVector;

import java.io.File;
import java.util.ArrayList;

import APKData.SmaliGraph.SICG;
import CandicateFamily.FamilyWeightScore;
import CommunityStructure.CommunityDetection.CommunityFinding;
import CommunityStructure.GraphData.GenerateCommunitySubgraph;
import ConstantVar.ConstantValue;
import GraphSimilarity.CommunitySubGraph;
import GraphSimilarity.SubGraphSimilarity;

public class APKSiggraphSet {
	private String filePath;
	private String actualFalName;
	private String predictFalName;
	private String fileName;
	private String outFilePath;
	private String clusterType="";
	//  元素为该APK的所有子图
	private ArrayList<CommunitySubGraph> subgraphList=new ArrayList<>();
	/*
	 *    元素为该APK的对应所有家族的显著性子图
	 */
	private ArrayList<CommunitySubGraph> simSigGraphList=new ArrayList<>();
	private ArrayList<Integer> featureInt=new ArrayList<>();
	private ArrayList<Double> featureDouble=new ArrayList<>();
	public APKSiggraphSet(){
	}
	public APKSiggraphSet(String apkFilePath, String clusterType){
		 this.filePath=apkFilePath;
		 File apkFile=new File(apkFilePath);
		 String apkName=apkFile.getName();
		 this.fileName=apkName;
		 this.clusterType=clusterType;
		 
		 if(apkFilePath.contains("train")){
			 int k=apkFilePath.lastIndexOf("/");
			 String outFileString=apkFilePath.substring(0,k+1);
			 File falDir=new File(outFileString);
			 this.actualFalName=falDir.getName();
			 outFileString +="apktool/"+fileName+"/";
			 this.outFilePath=outFileString;
		 }
		 else if(apkFilePath.contains("testData")){
			 int k=apkFilePath.lastIndexOf("/");
			 String outFileString=apkFilePath.substring(0,k+1);
			 File falDir=new File(outFileString);
			 this.actualFalName=falDir.getName();
			 outFileString +="apktool/out-"+fileName+"/";
			 this.outFilePath=outFileString;
		 }
		 else{
			 int k=apkFilePath.lastIndexOf("/");
			 String outFileString=apkFilePath.substring(0,k+1);
			 File falDir=new File(outFileString);
			 this.actualFalName=falDir.getName();
			 outFileString +="apktool/"+fileName+"/";
			 this.outFilePath=outFileString;
			// System.out.println(outFileString);
		 }
	}
	 /*
	  *     反编译apk文件并且生成相应的分析结果
	  */
	public void disassemble(String apkFilePath){
		 int k=apkFilePath.lastIndexOf("/");
		 String outFileString=apkFilePath.substring(0,k+1);
		 File outFileDir=new File(outFileString);
		 this.actualFalName=outFileDir.getName();
		 outFileString +="apktool/"+fileName+"/";
		 SICG sicg=new SICG(apkFilePath, outFileString);
		 this.outFilePath=outFileString;
	}
    /*
     *     进行社团划分，需要输入解析结果以及家族分值列表文件作为参数
     */
	public void communityDivide(){
		/*
		 *   采用社团划分算法将原图划分成为若干个子图
		 */
		CommunityFinding communityFinding=new CommunityFinding(outFilePath);
		 System.out.println("\n Finish Community Detection");
	}
	/*
	 *    生成每一个算法的生成的子图集合，需要一个分值列表文件作为参数
	 */
	public void createCommunityFiles(String weightScoreFilePath){
		GenerateCommunitySubgraph generateCommunitySubgraph=new GenerateCommunitySubgraph(outFilePath, weightScoreFilePath);
//		System.out.println("Finsh CommunityFile Creation");
	}
	public void reiniGraphList(){
		this.subgraphList=new ArrayList<>();
		this.simSigGraphList=new ArrayList<>();
	}
	 /*
	  *     存储该样本的所有生成子图
	  */
	public void storeAllSubgraphs(){
		 String type="";
		 int k=clusterType.indexOf("-");
		 type=clusterType.substring(0,k);
		 String graphFilePath=this.outFilePath+"SICG/Community/Community_"+type+"/";
		// System.out.println(graphFilePath);
		 File graphFile=new File(graphFilePath);
		 File subgraphFile[]=graphFile.listFiles();
		 for(int i=0;i<subgraphFile.length;i++){
			 CommunitySubGraph subGraph=new CommunitySubGraph(subgraphFile[i].getAbsolutePath());
			 double score=subGraph.getSensitiveScore();
			// if(score>=ConstantValue.getVar().minTotalGraphScore){
				 subgraphList.add(subGraph);
			// }
		 }
	}
	/*
	 *      存储该样本对于所有家族的显著性子图
	 */
	public void storeAllSignificantSubgraphs(){
		File dataFile=new File(ConstantValue.getVar().FAMILIESDIRPATH_STRING);
		File family[]=dataFile.listFiles();
		for(int i=0;i<family.length;i++){
			addFalSignificantSubgraphs(family[i].getAbsolutePath());
		}
	}
	public void addFalSignificantSubgraphs(String familyDirPath){
		String weightScoreFilePath=familyDirPath+"/FamilyInfo/MethodWeight.txt";
		FamilyWeightScore weightScore=new FamilyWeightScore(weightScoreFilePath);
		File clusterFile=new File(familyDirPath+"/FamilyInfo/"+clusterType+"/Cluster/");
		File gexfFile[]=clusterFile.listFiles();
		for(int i=0;i<gexfFile.length;i++){
			CommunitySubGraph srcGraph=new CommunitySubGraph(gexfFile[i].getAbsolutePath()); 
			for(int j=0;j<subgraphList.size();j++){
				CommunitySubGraph dstGraph=subgraphList.get(j);
				SubGraphSimilarity similarity=new SubGraphSimilarity(srcGraph.getGraph(), dstGraph.getGraph(), weightScore);
				if(similarity.getSimScore()>ConstantValue.getVar().minScoreSim){
					simSigGraphList.add(srcGraph);
					break;
				}
			}
		}
	}
	public String showSigGraphList(){
		String resultString="";
		for(int i=0;i<simSigGraphList.size();i++){
			resultString +=simSigGraphList.get(i).getFilePath()+"\n";
		}
		return resultString;
	}

	public void generateVector(FregraphVector vector){
		ArrayList<Fregraph> fregraphList=new ArrayList<>();
		fregraphList=vector.fregraphList;
		for(int i=0;i<fregraphList.size();i++){
			boolean in=false;
			for(int j=0;j<simSigGraphList.size();j++){
				if(fregraphList.get(i).inFeature(simSigGraphList.get(j).getFilePath())){
				     in=true;
				     break;
				}
			}
			if(in==true){
				featureInt.add(1);
				//  如果该样本是训练集样本
				double tmp=fregraphList.get(i).weight;
				featureDouble.add(tmp);
//				if(this.filePath.contains("train")){
//	//				System.out.println(i+": "+featureList.get(i).FeatureString());
//					String falName=this.actualFalName;   //存储本样本的实际家族
////					double tmp=featureList.get(i).getSigraphScoreWithFalName(falName);   // 返回该特征相对于该
////					//已知样本子图的有效分值
//					/*
//					 *     	返回该特征的熵值
//					 */
//					double tmp=featureList.get(i).getWeight();
//					featureDouble.add(tmp);
//				}
//				else if(this.filePath.contains("test")){
//	//				System.out.println(i+": "+featureList.get(i).FeatureString());
//			//		double tmp=featureList.get(i).getSiggraphScoreWithoutFalName();
//					double tmp=featureList.get(i).getWeight();
//					featureDouble.add(tmp);
//				}
//				else{
//					double tmp=featureList.get(i).getWeight();
//					featureDouble.add(tmp);
//				}
			}
			else{
				featureInt.add(0);
				featureDouble.add(0.0D);
			}
		}
	}
	public String getFeatureIntVector(){
		String resultString="";
		for(int i=0;i<featureInt.size();i++){
			resultString +=featureInt.get(i)+",";
		}
		resultString +=this.actualFalName;
		return resultString;
	}
	public String getFeatureDoubleVector(){
		String resultString="";
		for(int i=0;i<featureInt.size();i++){
			resultString +=featureDouble.get(i)+",";
		}
		resultString +=this.actualFalName+"/"+this.fileName;
	//	resultString +=this.actualFalName;
		return resultString;
	}
	public String getFeatureDoubleVectorWithAPKName(){
		String resultString="";
		for(int i=0;i<featureInt.size();i++){
			resultString +=featureDouble.get(i)+",";
		}
		resultString +=this.actualFalName+"/"+this.fileName;
		return resultString;
	}
	public String getFeatureDoubleValueWithoutLabel(){
		String resultString="";
		for(int i=0;i<featureInt.size();i++){
			resultString +=featureDouble.get(i)+",";
		}
		resultString +="?";
		return resultString;
	}
}
