package CommunityStructure.CommunityDetection;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;

import ConstantVar.ConstantValue;

/*
 *     输入为一个对象的反编译后的文件夹的路径，对其中SICG文件夹中的ReducedGraph.dot当作输入
 *     运行社团发现算法，分别为
 *     infomap
 *     fast greedy 
 *     propagation
 *     multilevel
 *     得到四种社团划分结果
 */
public class CommunityFinding {
			private String srcFilePathString="";
			private String outPutPathString="";
			
			public CommunityFinding(String srcFilePathString){
				this.srcFilePathString=srcFilePathString+"SICG/ReducedGraph.dot";
	//			this.srcFilePathString=srcFilePathString+"SICG/SourceGraph.dot";
				this.outPutPathString=srcFilePathString+"SICG/Community";
				File file=new File(outPutPathString);
				if(!file.exists()){
					file.mkdir();
				}
				exePython(this.srcFilePathString, this.outPutPathString+"/");
			}
			public void exePython(String inputFileString, String outputFileString){
				ConstantValue.getVar();
				String cmdString="python2.7 "+ConstantValue.CONMMUNITYDETECTIONPYTHONFILEPATH_STRING+" "+inputFileString+" "+
						outputFileString;
				System.out.println(cmdString);
				exeCmd(cmdString);
			}
			public void exeCmd(String cmd){
				Runtime rnRuntime=Runtime.getRuntime();
				String outInfo="";
				try {
					Process process=rnRuntime.exec(cmd);
					InputStream in = ( process).getErrorStream();//得到错误信息输出。
					BufferedReader br = new BufferedReader(new InputStreamReader(in));
					String line = "";
					while ( (line = br.readLine())!= null) {
						outInfo = outInfo + line + "\n";
					} 
					//System.out.println(outInfo);
				}
					catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
			}
}
