package CommunityStructure.CommunityDetection;

import java.io.File;

import CommunityStructure.GraphData.GenerateCommunitySubgraph;
import Util.Tool.DirDelete;

public class OneObjectCommunityDetection {
			private String inputAPKFilePath;
			private String weightScoreFilePath;
			
			public OneObjectCommunityDetection(String inputFilePath, String weightScoreFilePath){
				this.inputAPKFilePath=inputFilePath;
				this.weightScoreFilePath=weightScoreFilePath;
				/*
				 *    执行python文件
				 */
				/*
				 *   采用社团划分算法将原图划分成为若干个子图
				 */
				CommunityFinding communityFinding=new CommunityFinding(inputFilePath);
				/*
				 *   将划分结果存储到相应的文件夹中
				 */
				GenerateCommunitySubgraph generateCommunitySubgraph=new GenerateCommunitySubgraph(inputFilePath, weightScoreFilePath);
				/*
				 * 删除多余文件，保留Community_Im以及Community_Result_im.csv
				 */
				deleteMoreFile(inputFilePath);
			}
			public void deleteMoreFile(String inputFileString){
				File file=new File(inputFileString+"SICG/Community/");
				File subfile[]=file.listFiles();
				for(int i=0;i<subfile.length;i++){
					String filePath=subfile[i].getAbsolutePath();
					if(filePath.contains("Community_Im")||filePath.contains("Community_Result_im.csv")){
						
					}
					else{
						DirDelete delete=new DirDelete();
						delete.deleteDir(subfile[i]);
					}
				}
				
			}
}
